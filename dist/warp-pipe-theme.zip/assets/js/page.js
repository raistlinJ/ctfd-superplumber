import Alpine from "alpinejs";
import CTFd from "./index";
import "./theme/superplumber";

window.CTFd = CTFd;
window.Alpine = Alpine;

Alpine.start();
